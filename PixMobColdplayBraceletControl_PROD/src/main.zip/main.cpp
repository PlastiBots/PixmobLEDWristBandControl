#include <Arduino.h>


#include <M5StickCPlus.h>
#include "AXP192.h"         //M5Stick-C Plus
#include <IRremoteESP8266.h>
#include <IRsend.h>
#include <Wire.h>
#include "fonts/Orbitron_ExtraBold9pt7b.h"
#include "fonts/Orbitron_ExtraBold12pt7b.h" 
#include "fonts/Orbitron_ExtraBold14pt7b.h" 


//##############################################################################
// D E B U G  - set True to turn on Serial Debugging
#define debug false
//##############################################################################

//#define LDRSensorPIN 33                // 26 causes issues, so dont use it
//#define CAMERA HERO7                   // Change here for your camera

// SET THIS TO THE DATA PIN USED FOR THE IR TRANSMITTER
const uint16_t IrLed = 9;

boolean whichTab = 0;                  // TabSelection
int setupMenuItem = 1;                 // For menuing system
boolean useGPSlider = 0;               // Using GoPro Camera motorized rail?
int printLayersIncrement = 2;          // Layercount counter increment
int sliderIncrementMS = 5;             // factor to determine how far slider moves with each layer change
int numPrintLayers = 200;              // # of layers sliced. Start at 200 as lowest value acceptable
int maxNumLayers = 1450;               // Set as max reasonable layers for most common prints. Mars 3 does about 3400 max, but will stop slider at this point



//int pc = 0;                            // For LDR
//boolean frameCapture = false;
uint16_t frame_cnt = 0;
boolean recording = false;             // Used to set recording to start.
//boolean frameCaptured = false;         // Wwhen a frame is being captured
boolean idleTriggered = false;         // So idle trigger does not continue after stopped
long current_frame_time;
int frameSkip = 0;                     // Allows to skip every x frames (2 or 4) to speed up time-lapse
int frameSkipCnt = 0;                  // Tracking counter
long time_to_wait_till_print_done = 120 * 1000;  //120 seconds. Need to allot for time for Z to move + time for exposure. Also consider when print is large and z has to move all the way up. Assumption is print is done if no transition from UV on to off for X seconds
long prevUpdateMillis = 0;
long updateIntervalMS = 2000;          // Update the display status (bottom area) every 2 seconds
char battStats[40] = "" ; 

//LED Sequences
const uint16_t yellow3Fade6[] = {1400,1400,700,700,700,700,1400,2800,700,2100,700,700,700,1400,700,1400,1400,2800,1400,2800,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  //WORKS
const uint16_t redFade6[] = {1400,1400,700,700,700,1400,700,2800,700,2100,1400,700,700,700,700,1400,1400,2800,1400,2800,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  
const uint16_t magentaFade6[] = {700,700,700,700,1400,1400,1400,2800,700,2100,1400,2100,700,700,700,700,1400,2100,700,700,700,2100,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  
const uint16_t greenFade6[] = {1400,1400,700,700,700,700,1400,2800,700,1400,700,1400,700,1400,700,1400,1400,2800,1400,2800,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  
const uint16_t blueFade6[] = {700,700,700,2100,1400,1400,700,2100,700,1400,700,700,700,1400,1400,700,700,1400,700,700,700,700,700,700,700,2100,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  
const uint16_t redOrangeFade6[] = {700,700,700,700,1400,1400,1400,2800,700,2800,1400,1400,700,700,700,1400,700,2100,1400,2800,700,1400,700,1400,1400,700,700,1400,1400,2800,1400,2800,700};  
const uint16_t specialRandomFade[] = {700,700,700,2100,1400,700,700,2800,700,700,700,1400,700,2100,700,700,700,1400,700,1400,700,1400,700,2100,700};  


const int yellow3Fade6_len = sizeof(yellow3Fade6) / sizeof(yellow3Fade6[0]);
const int redFade6_len = sizeof(redFade6) / sizeof(redFade6[0]);
const int magentaFade6_len = sizeof(magentaFade6) / sizeof(magentaFade6[0]);
const int greenFade6_len = sizeof(greenFade6) / sizeof(greenFade6[0]);
const int blueFade6_len = sizeof(blueFade6) / sizeof(blueFade6[0]);
const int redOrangeFade6_len = sizeof(redOrangeFade6) / sizeof(redOrangeFade6[0]);
const int specialRandomFade_len = sizeof(specialRandomFade) / sizeof(specialRandomFade[0]);

//FUNCTION DECLARATIONS
void lcdClear();
void updateStats();
void updateStatsMsg(String textToShow, int xVal, uint16_t clr);
const char *formatM5BattInfo(float battV, float battPwr, float usbV, char * battStats);
void setupHMI(int tab, int menuItem, int settingChange);
boolean CanISkipAFrame();

void sendyellow3Fade6();
void sendredFade6();
void sendmagentaFade6();
void sendgreenFade6();
void sendblueFade6();
void sendredOrangeFade6();
void sendspecialRandomFade();



IRsend irsend(IrLed);

void setup() 
{

  Serial.begin(115200);
  irsend.begin();
    
  M5.begin();                             // Initialize M5StickC Plus.
    
  M5.Lcd.setRotation(3);                  // Rotate the screen.
  setupHMI(whichTab, setupMenuItem, 0);         // Show initial HMI interface


  sendyellow3Fade6();delay(1000);  //delays are needed, else some dont fire.
  sendredFade6();delay(1000);
  sendmagentaFade6();delay(1000);
  sendgreenFade6();delay(1000);
  sendblueFade6();delay(1000);
  sendredOrangeFade6();delay(1000);
  sendspecialRandomFade();delay(1000);
    
}

void loop() 
{
  unsigned long currUpdateMillis = millis();
  M5.update();                            // Read the press state of the key.

  
  
  if(M5.BtnB.wasPressed())
  {
    setupMenuItem++;
    
    if (setupMenuItem > 4) 
    {
      whichTab=!whichTab; 
      setupMenuItem = 1;
    }
    setupHMI(whichTab, setupMenuItem, 0);
  }

  if (M5.BtnA.wasPressed()) 
  {
    if(!whichTab)  //make sure we are in the Run tab
    {
      printLayersIncrement = 2;
      setupHMI(whichTab, setupMenuItem, 1);  //change the selected setting
    } else {
      if (debug) {Serial.println("In RUN tab, do run conn stuff etc with this button");}
      recording = !recording;  //toggle the value
      //M5.Beep.beep();
      //updateStatsMsg("    Recording Started", 6, TFT_GREEN);

  
      

      if (!recording)  //if recording was stopped, also close the connection with the GoPro (IMPORTANT!)
      {
        updateStatsMsg("   Recording Stopped", 6, TFT_YELLOW);
        idleTriggered = false;  //reset
        frame_cnt=0;            //reset
      }
     
      if (debug) {Serial.print("Recording toggled as: ");Serial.println(recording);}
      current_frame_time = millis();   //reset idle trigger time when recording starts or stops     
    }
  }

  //Used to set # of layers - changes by increments of 20 on Settings Tab
  if(M5.BtnA.pressedFor(1000) && setupMenuItem == 3)
  {
    printLayersIncrement = 20;
    setupHMI(whichTab, setupMenuItem, 1);  //change the selected setting - mostly used to rapidly increase the layer count
  }

  //Hold the B button down to reset the GoPro slider toward star position
  if(M5.BtnB.pressedFor(1000))
  {
    
    delay(20);
  }



  //Idle Timeout:  use a timer to set recording false if idle for a period of time
  if (millis() > current_frame_time + time_to_wait_till_print_done && !idleTriggered && recording)
  {
    recording = false;   //stop recording
    if (debug) {Serial.println(" Idle Timeout triggered:  Stopping");}
    updateStatsMsg(" Idle Timeout Triggered", 6, TFT_YELLOW);
    idleTriggered = true;
    M5.Beep.beep();M5.Beep.beep();
  }

  //regular updates to the HMI - only show if on Run tab
  if (currUpdateMillis - prevUpdateMillis > updateIntervalMS && whichTab==1)
  {
    updateStats(); 
    if (debug) {Serial.println("Update Stats:  Should only be every 2 seconds..");}

    //Once recording, show other status updates like battery etc.
    if (recording)
    {
      updateStatsMsg(formatM5BattInfo(M5.Axp.GetBatVoltage(), M5.Axp.GetBatPower(), M5.Axp.GetVBusVoltage(), battStats), 8, TFT_GREEN);
      //Serial.print("Batt Stuff:  ");Serial.println(formatM5BattInfo(M5.Axp.GetBatVoltage(), M5.Axp.GetBatPower(), M5.Axp.GetVBusVoltage(), battStats));  
    }   
    prevUpdateMillis = currUpdateMillis;
  }

 
  
}  //END LOOP

//########################################################################################
//########################################################################################
void sendspecialRandomFade()
{
  irsend.sendRaw(specialRandomFade, specialRandomFade_len, 38);delay(3);
}
//########################################################################################

void sendredOrangeFade6()
{
  irsend.sendRaw(redOrangeFade6, redOrangeFade6_len, 38);delay(3);
}
//########################################################################################

void sendblueFade6()
{
  irsend.sendRaw(blueFade6, blueFade6_len, 38);delay(3);
}
//########################################################################################


void sendgreenFade6()
{
  irsend.sendRaw(greenFade6, greenFade6_len, 38);delay(3);
}
//########################################################################################


void sendmagentaFade6()
{
  irsend.sendRaw(magentaFade6, magentaFade6_len, 38);delay(3);
}
//########################################################################################

void sendredFade6()
{
  irsend.sendRaw(redFade6, redFade6_len, 38);delay(3);
}
//########################################################################################

void sendyellow3Fade6() {
  irsend.sendRaw(yellow3Fade6, yellow3Fade6_len, 38);delay(3);
}
//########################################################################################


void lcdClear()
{
  M5.Lcd.fillScreen(BLACK);  
}
//########################################################################################

void setupHMI(int tab, int menuItem, int settingChange)
{
  //fillRect(x, y, w, h, color);
  //drawRoundRect(x, y, w, h, radius, colour)
  //drawLine(x0, y0, x1, y1, color);
  //drawCircle(x0, y0, r, color);
  //fillCircle(x0, y0, r, color);
  //drawTriangle(x0, y0, x1, y1, x2, y2, color);
  //fillTriangle(x0, y0, x1, y1, x2, y2, color);
  //screen is 135H x 240W

  lcdClear();
  if (!whichTab)
  {
    //M5.Lcd.drawRoundRect(119, 5, 116, 24, 4, TFT_DARKGREY);    //RUN Tab
    M5.Lcd.drawRoundRect(127, 5, 109, 24, 4, TFT_GREEN);         //RUN Tab
    M5.Lcd.fillRect(120, 26, 114, 4, TFT_BLACK);
  
    M5.Lcd.drawRoundRect(4, 5, 116, 24, 4, TFT_BLUE);    //SETUP Tab box
    M5.Lcd.drawRoundRect(4, 26, 232, 109, 4, TFT_BLUE);  //box around rest of screen
    M5.Lcd.fillRect(5, 26, 114, 4, TFT_BLACK);           //blank out line below setup text
    M5.Lcd.drawLine(4, 15, 4, 30, TFT_BLUE);             //Tiny line connecting upper tab to lower box
    //S E T U P tab
    M5.Lcd.setFreeFont(&Orbitron_ExtraBold9pt7b);
    M5.Lcd.setCursor(12, 23);
    M5.Lcd.setTextColor(TFT_BLUE); 
    M5.Lcd.print("S E T U P");   
    //R U N  tab
    M5.Lcd.setCursor(150, 23);
    M5.Lcd.setTextColor(TFT_GREEN); 
    M5.Lcd.print("R U N");   

    //Frame Skip Option
    M5.Lcd.setTextColor(TFT_BLUE);
    M5.Lcd.setCursor(25, 60); 
    M5.Lcd.print("FRAME SKIP");  
    if (!frameSkip)
    {
      M5.Lcd.drawRoundRect(185, 47, 38, 15, 6, TFT_BLUE); 
      M5.Lcd.fillCircle(190, 54, 11, TFT_BLUE);
      M5.Lcd.fillCircle(190, 54, 10, TFT_DARKGREY);
    } else {
      M5.Lcd.drawRoundRect(185, 47, 38, 15, 6, TFT_BLUE); 
      M5.Lcd.fillCircle(214, 54, 11, TFT_BLUE);
      M5.Lcd.fillCircle(214, 54, 10, TFT_GREEN);
    }
   
    //Use GoPro Slider Option
    M5.Lcd.setTextColor(TFT_BLUE);
    M5.Lcd.setCursor(25, 90); 
    M5.Lcd.print("USE SLIDER");  
    if (!useGPSlider)
    {
      M5.Lcd.drawRoundRect(185, 79, 38, 15, 6, TFT_BLUE); 
      M5.Lcd.fillCircle(190, 86, 11, TFT_BLUE);
      M5.Lcd.fillCircle(190, 86, 10, TFT_DARKGREY);
    } else {
      M5.Lcd.drawRoundRect(185, 79, 38, 15, 6, TFT_BLUE); 
      M5.Lcd.fillCircle(214, 86, 11, TFT_BLUE);
      M5.Lcd.fillCircle(214, 86, 10, TFT_GREEN);
    }

   //Layer Count Setting Change
    M5.Lcd.setTextColor(TFT_BLUE);
    M5.Lcd.setCursor(25, 120); 
    M5.Lcd.print("# LAYERS"); 
    
    M5.Lcd.fillRect(155, 105, 70, 20, TFT_BLACK); 
    if (useGPSlider) 
    {
      M5.Lcd.setTextColor(TFT_GREEN);   //show text enabled
    } else { 
      M5.Lcd.setTextColor(TFT_DARKGREY);  //show text as disabled
    }
    
    M5.Lcd.setCursor(175, 121); 
    M5.Lcd.print(numPrintLayers);  
     
    switch (menuItem) 
    {
      case 1:
        //FRAME SKIP SETTING
        M5.Lcd.fillTriangle(10, 62, 10, 48, 20, 55, TFT_RED); //0 set is bottom, 1st is top, 2nd is right point
        if (settingChange)
        {
          frameSkip = !frameSkip;
          setupHMI(whichTab, menuItem, 0);   //refresh the menu
        }
      break;
      case 2:
        //USE SLIDER SETTING
        M5.Lcd.fillTriangle(10, 91, 10, 77, 20, 84, TFT_RED); //0 set is bottom, 1st is top, 2nd is right point
        if (settingChange)
        {
          useGPSlider = !useGPSlider;
          setupHMI(whichTab, menuItem, 0);   //refresh the menu
        }
      break;
      case 3:
        //LAYER COUNT SETTING
        M5.Lcd.fillTriangle(10, 122, 10, 108, 20, 115, TFT_RED); //0 set is bottom, 1st is top, 2nd is right point
        if (settingChange)
        {
          //update layer count # here
          numPrintLayers+=printLayersIncrement;
          if (numPrintLayers > maxNumLayers) numPrintLayers = 200;  //roll it over back to default
          //Work out the slider increment factor
          sliderIncrementMS = map(numPrintLayers, 200, maxNumLayers, 5, 2); //map(value, fromLow, fromHigh, toLow, toHigh)
          //Testing:  at 3ms ~ 1430 movements, 5ms ~ 423 movements, 15ms ~ 193 movements

          if (debug) {Serial.print("sliderIncrementMS= ");Serial.print(sliderIncrementMS);Serial.print(" As INT= ");Serial.println((int)sliderIncrementMS);}
          
          setupHMI(whichTab, menuItem, 0);   //refresh the menu 
          delay(100);
        }        
      break;
      case 4:   //done setup menu. Go to run Tab
         whichTab=!whichTab;
         setupHMI(whichTab, 1, 0);
         if (debug) {Serial.println(whichTab);}
       break;

      default:
        // statements
      break;
    }
    
  }else{  // whichTab 1 - showing RUN tab section
    
    //R U N  tab box
    M5.Lcd.drawRoundRect(127, 5, 109, 24, 4, TFT_GREEN);         //RUN Tab
    M5.Lcd.fillRect(120, 26, 114, 4, TFT_BLACK);
  
    M5.Lcd.drawRoundRect(4, 26, 232, 109, 4, TFT_GREEN);  //box around rest of screen
    M5.Lcd.fillRect(128, 26, 108, 4, TFT_BLACK);         //blank out line below setup text
    M5.Lcd.drawLine(235, 15, 235, 30, TFT_GREEN);         //Tiny line connecting upper tab to lower box

    //Run tab menu
    M5.Lcd.setCursor(150, 23);
    M5.Lcd.setTextColor(TFT_GREEN); 
    M5.Lcd.print("R U N");   

    //Items
    M5.Lcd.setCursor(10, 55); 
    M5.Lcd.setTextColor(TFT_BLUE); 
    M5.Lcd.print("R E C O R D"); 
    M5.Lcd.setCursor(155, 55); 
    M5.Lcd.setTextColor(TFT_RED); 
    M5.Lcd.print("O F F");    

    M5.Lcd.setCursor(10, 80); 
    M5.Lcd.setTextColor(TFT_BLUE); 
    M5.Lcd.print("F R A M E #"); 
    M5.Lcd.setCursor(155, 80); 
    M5.Lcd.setTextColor(TFT_GREEN); 
    M5.Lcd.print("0");     

    //Status Box
    //M5.Lcd.fillRect(2, 91, 234, 109, TFT_LIGHTGREY); 
    M5.Lcd.fillRoundRect(4, 89, 232, 46, 4, TFT_BLACK); 
    M5.Lcd.drawRoundRect(4, 89, 232, 46, 4, TFT_GREEN);  //drawRoundRect(x, y, w, h, radius, colour)

  }
}

//########################################################################################

void updateStats()
{
  M5.Lcd.setFreeFont(&Orbitron_ExtraBold9pt7b);

  //Update Record State
  M5.Lcd.fillRect(150, 35, 70, 25, TFT_BLACK);  //screen is 135H x 240W  //fillRect(x, y, w, h, color);
  M5.Lcd.setCursor(160, 55); 
  if (recording)
  {
    M5.Lcd.setTextColor(TFT_GREEN); 
    M5.Lcd.print("O N");   

  } else {
    M5.Lcd.setTextColor(TFT_RED); 
    M5.Lcd.print("O F F");      
  }
  
  //Update Frame Count
  M5.Lcd.fillRect(150, 65, 70, 20, TFT_BLACK);  //screen is 135H x 240W  //fillRect(x, y, w, h, color);
  M5.Lcd.setCursor(160, 80); 
  M5.Lcd.setTextColor(TFT_GREEN); 
  M5.Lcd.print(frame_cnt);   
}
//########################################################################################

void updateStatsMsg(String textToShow, int xVal, uint16_t clr)
{
  //M5.Lcd.drawRoundRect(4, 89, 232, 50, 4, TFT_PURPLE);  // see further up for this box
  //M5.Lcd.fillRect(11, 88, 230, 40, TFT_OLIVE);  //clear old values.  screen is 135H x 240W  //fillRect(x, y, w, h, color);
  M5.Lcd.fillRoundRect(4, 89, 232, 46, 4, TFT_BLACK);  // Also created above in setupHMI()
  M5.Lcd.drawRoundRect(4, 89, 232, 46, 4, TFT_GREEN);  //drawRoundRect(x, y, w, h, radius, colour)  
  M5.Lcd.setCursor(xVal, 108); //x,y
  M5.Lcd.setTextColor(clr);
  M5.Lcd.println(textToShow);
}
//##################################################################################
const char *formatM5BattInfo(float battV, float battPwr, float usbV, char * battStats)
{
  //char buffer[40] = "";
  //char bV[6];
  //char bP[6];
  //char uV[6];

  //dtostrf(battV, 6, 1, bV);
  //dtostrf(battPwr, 6, 1, bP);
  //dtostrf(usbV, 6, 1, uV);

  //sprintf(buffer, "BattV: %2.1f V BattP: %2.1f V USBV: %2.1f V", bV, bP, uV);
  sprintf(battStats, "BV: %2.1fV BPw: %2.1fmW \n            USBV: %2.1fV", battV, battPwr, usbV);
  //Serial.println(buffer);
  //Serial.print(battV);Serial.print("   ");
  //Serial.print(battPwr);Serial.print("   ");
  //Serial.println(usbV);
  
  return battStats;
  
  //sprintf(displayString, "value:%7d.%d%d", (int)num, int(num*10)%10, int(num*100)%10);
  //char buffer[40];
  //sprintf(buffer, "The %d burritos are %s degrees F", numBurritos, tempStr);
  //Serial.println(buffer);
  //dtostrf(float_value, min_width, num_digits_after_decimal, where_to_store_string)
}
//########################################################################################

boolean CanISkipAFrame()
{
  if (debug) {Serial.print("FrameSkipSetting: "); Serial.println(frameSkip);} 
  if (debug) {Serial.print("FrameSkipCount: "); Serial.println(frameSkipCnt);} 
  if (debug) {Serial.print("FrameCount: "); Serial.println(frame_cnt);} 
  if (debug) {Serial.println("");} 

  if (frameSkip)
  {
    if(frameSkipCnt <= 3)
    {
      frameSkipCnt++;     //still not at 4, skip
      return true; 
    } else {
      frameSkipCnt=0;
      return false;       //4th frame, take a pic
    }
  }

  return false;         //not skipping frames.  Record as normal
  
}
//##################################################################################
